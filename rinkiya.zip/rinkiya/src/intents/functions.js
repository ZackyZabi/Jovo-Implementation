const url = "http://dde.horizonblue.com/provider/api/search?specialties=ABA Certified Therapist&network=omt1, omt2&providertype=P&sort=omnia,distance&radius=5&zipcode=";
var array=[]; 
var rpn = require('request-promise-native')
module.exports= {
   
	getApi: async function(location)
	{
		array = []
		const api= await rpn.get(url+location)
		const res= JSON.parse(api);
       	res.providers.forEach(element => {
            array.push(element.firstname.toLowerCase());
        });
        return array;
	},

	getApi2:function(param)
	{
    return array.includes(param.toLowerCase());
	}

}


