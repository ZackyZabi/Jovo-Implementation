var api=require('./functions.js')

module.exports = {

    async locationOptionIntent() {
        result = []
        if(this.$alexaSkill.hasSlotValue('location'))
            {   
                result= await api.getApi(this.$inputs.location.value)
            }
            else
            {
                result= await api.getApi('10001')
            }          
            
            var temp = result.slice(this.$app.$data.static, this.$app.$data.iterator);

        this.ask('for your location '+temp)
        this.$app.$data.static = this.$app.$data.iterator;
        this.$app.$data.iterator = this.$app.$data.iterator +2;
        
}
}
