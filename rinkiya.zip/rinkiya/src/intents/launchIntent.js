module.exports={
   async NEW_SESSION()
    {
    	try {
            console.log('aaa')
            const name = await this.$alexaSkill.$user.getName();
            const email = await this.$alexaSkill.$user.getEmail();
            const mobileNumber = await this.$alexaSkill.$user.getMobileNumber();
            //const postalCode = await this.$alexaSkill.$user.getCountryAndPostalCode();
            console.log('aan')
           
          let value = {
                fullname : name,
                emailaddress : email,
                contactNumber : mobileNumber.phoneNumber,
           }
            this.$app.$data.key = value;
            this.$app.$data.static = 0;
            this.$app.$data.iterator = 3;
            
            console.log('aaaaa')
            this.$speech.addText('Welcome to liberty mutual, would you like to continue with 10001 location?');
            this.$reprompt.addText('Please answer with yes or no.');
    
            this.followUpState('OrderState')
                .ask(this.$speech, this.$reprompt);
            
            } catch(error) {
            if (error.code === 'NO_USER_PERMISSION') {
                this.$alexaSkill.showAskForCountryAndPostalCodeCard()
                    .tell(`Please grant access to your address in the Alexa app.`);
            } else {
                // Do something
            }
        }
    },
    OrderState: {

        YesIntent() {
          return this.toIntent('locationOptionIntent') 
        },

        NoIntent() {
            this.tell('sorry, you are not suppose to say no')
        },
    },
}

