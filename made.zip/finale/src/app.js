'use strict';

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const launchIntent = require('./intents/launchIntent.js')
const locationIntent = require('./intents/locationIntent.js')
const bookAppointmentIntent = require('./intents/bookIntent.js')

const app = new App();


app.use(
    new Alexa()
);

app.setHandler(
launchIntent,
locationIntent,
bookAppointmentIntent,
{
});

module.exports.app = app;
