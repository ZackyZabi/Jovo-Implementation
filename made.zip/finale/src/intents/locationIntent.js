module.exports = {

    async locationOptionIntent() {         
        
        if(this.$app.$data.static-1<this.$app.$data.result.length)
    {    var temp = this.$app.$data.result.slice(this.$app.$data.static, this.$app.$data.iterator);

        if(this.$app.$data.static==0)    
            this.ask('These are the few show '+temp+' do you want some more')
        else
            this.ask(''+temp+'')
        
        this.$app.$data.static = this.$app.$data.iterator;
        this.$app.$data.iterator = this.$app.$data.iterator + 3;
    }   else
            this.tell('There is no more data, so try booking from the first')
        
}
}
