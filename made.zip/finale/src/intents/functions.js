const url = "http://dde.horizonblue.com/provider/api/search?specialties=ABA Certified Therapist&network=omt1, omt2&providertype=P&sort=omnia,distance&radius=5&zipcode=";
var array=[];
var post_params=[] 
var rpn = require('request-promise-native')
var fs = require('fs')
module.exports= {
   
	getApi: async function(location)
	{			
		var token='';
		var url = "https://retail.horizonbluedev.com/user/login?_format=json"
		var header = {
			'Content-Type':'application/json',
			'Authorization':'Basic c2l0ZWFkbWluOmFkbWluMTIz'
		}
		var obj = {
		'name' : 'alexa',
		'pass' : 'xUTaNuw-AU'
		}
		var shopData = async (url,token1)=>{
			try{
				var set = await rpn.get(url, {headers :token1}) 	
			}
			catch(error){
			console.log(error.message)
}}

		var loginData = async (url,obj,header)=>{
			var putis = await rpn.post(url,{json:obj,headers:header})
			token=putis.csrf_token;
			console.log(token)
			var url1="https://retail.horizonbluedev.com/hc2/api/location/search?_format=json&zipcode=07105"
			var tokencsrf = {
			'Authorization':'Basic c2l0ZWFkbWluOmFkbWluMTIz',
			'Content-Type':'application/json',
			'X-CSRF-Token': token
			}
			await shopData(url1,tokencsrf); 
			}
		async function hero(){
		await loginData(url,obj,header); 
		}
		hero()


			post_params=[]
			array = []
			let data = fs.readFileSync('D:/task/finale/src/intents/response.json');  
			let result = JSON.parse(data);
			result.locations.forEach(element => {
			let obj={}
			obj.id=element.id;
			obj.name=element.name;
			obj.channel_id=element.channel_id;
			array.push(obj.name.toLowerCase())
			post_params.push(obj)
			 });
		return array;
		
	},

	getApi2:function(param)
	{

    return array.includes(param.toLowerCase());
	},

	

}


