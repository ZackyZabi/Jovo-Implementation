var api=require('./functions.js')
var rpn = require('request-promise-native')
module.exports = {
    async bookAppointmentIntent() {
        
        if(this.$alexaSkill.hasSlotValue('shop') ){
                if(!api.getApi2(this.$inputs.shop.value)) 
                {   
                    this.$alexaSkill.$dialog.elicitSlot('shop', 'The shopname that you have selected is not valid. Please select a valid shop name ', 'Your selection is invalid. Please select a valid shop name. ')
                }

                else if (this.$alexaSkill.hasSlotValue('time') && (this.$inputs.time.value == 'MO' | this.$inputs.time.value == 'EV' | this.$inputs.time.value == 'NI' | this.$inputs.time.value == 'AF')) 
                {
                    this.$alexaSkill.$dialog.elicitSlot('time', 'be specific on the ' + this.$inputs.time.value + '.', 'once again please')
                } else if (!this.$alexaSkill.$dialog.isCompleted()) 
                {
                    if (this.$alexaSkill.hasSlotValue('date') && this.$alexaSkill.hasSlotValue('time') && this.$alexaSkill.hasSlotValue('customerType') && this.$alexaSkill.hasSlotValue('reasonForVisit') && this.$alexaSkill.hasSlotValue('shop')) 
                    {
                        
                        let gName = this.$app.$data.key.fullname
                        let arry = gName.split(' ')
                        
                        let updatedIntent = {
                            name: 'bookAppointmentIntent',
                            confirmationStatus: 'NONE',
                            slots: {
                                customerType: {
                                    name: 'customerType',
                                    value: this.$inputs.customerType.value,
                                    confirmationStatus: 'NONE',
                                },
                                reasonForVisit: {
                                    name: 'reasonForVisit',
                                    value: this.$inputs.reasonForVisit.value,
                                    confirmationStatus: 'NONE',
                                },
                                firstName: {
                                    name: 'firstName',
                                    value: arry[0],
                                    confirmationStatus: 'NONE',
                                },
                                lastName: {
                                    name: 'lastName',
                                    value: arry[1],
                                    confirmationStatus: 'NONE',
                                },
                                date: {
                                    name: 'date',
                                    value: this.$inputs.date.value,
                                    confirmationStatus: 'NONE',
                                },
                                time: {
                                    name: 'time',
                                    value: this.$inputs.time.value,
                                    confirmationStatus: 'NONE',
                                },
                                bookAnAppointment: {
                                    name: 'bookAnAppointment',
                                    confirmationStatus: 'NONE',
                                },
                                 shop: {
                                    name: 'shop',
                                    value: this.$inputs.shop.value,
                                    confirmationStatus: 'NONE',
                                },

                            }
                        }
                        this.$alexaSkill.$dialog.delegate(updatedIntent)
                    } 
                    else {

                        this.$alexaSkill.$dialog.delegate()
                    }
                } 

              else{
               
                this.$speech.addText('Okay noted. Appointment on '+this.$inputs.date.value+' '+this.$inputs.time.value+' for the purpose of '+this.$inputs.reasonForVisit.value+' is marked, do you like to confirm');
                this.$reprompt.addText('Please answer with yes or no.');
        
                this.followUpState('perderState')
                    .ask(this.$speech, this.$reprompt);
                }
           }
           else
           {
            return this.toIntent('NEW_SESSION') 
           }      

},
perderState: {

    YesIntent() {
        var url = 'https://retail.horizonbluedev.com/hc2/api/channel/2/instance/2/create_apt?_format=json'
		var obj= 
		{
			"apt_slot_session_id": 0,
			"first": "string",
			"last": "string",
			"middle": "string",
			"email": "string",
			"reference_id": 0,
			"phone": "string",
			"phone_carrier": "string",
			"reason": "string",
			"type": "string",
			"hear_about_us": "string",
			"rightnow": true
		  }
	
		var header= {'content-type' : 'application/json',
		'Authorization':'Basic c2l0ZWFkbWluOmFkbWluMTIz'}
		try{ rpn.post(url,{json:obj,headers:header})
        }
        catch(error){console.log(error.message)}
        this.tell('Thank you for booking an appointment. your appointment is successfully booked and details are emailed to you.') 
    },

    NoIntent() {
        this.tell('fine, your appointment have been cancelled')
    },
},
}