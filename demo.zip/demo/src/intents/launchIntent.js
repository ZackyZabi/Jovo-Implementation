module.exports={
   async LAUNCH()
    {
    	
        return this.toIntent('locationIntent');
    }
}

