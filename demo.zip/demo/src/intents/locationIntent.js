var api=require('./functions.js')

module.exports = {

    async locationIntent() {

        var result=[];
        try {
        console.log('aaa')
        const name = await this.$alexaSkill.$user.getName();
        const email = await this.$alexaSkill.$user.getEmail();
        const mobileNumber = await this.$alexaSkill.$user.getMobileNumber();
        //const postalCode = await this.$alexaSkill.$user.getCountryAndPostalCode();
        console.log('aan')

        if(this.$alexaSkill.hasSlotValue('location'))
        {   
            result= await api.getApi(this.$inputs.location.value)
          
        }
        else
        {
            result= await api.getApi('07105')
  

        }
       
      let value = {
            fullname : name,
            emailaddress : email,
            contactNumber : mobileNumber.phoneNumber
       }
        this.$app.$data.key = value;
        this.ask(`Select from the following shop names ${result}`)

        
        } catch(error) {
        if (error.code === 'NO_USER_PERMISSION') {
            this.$alexaSkill.showAskForCountryAndPostalCodeCard()
                .tell(`Please grant access to your address in the Alexa app.`);
        } else {
            // Do something
        }
    }
},
}
