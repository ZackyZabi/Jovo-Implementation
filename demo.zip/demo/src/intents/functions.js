const url = "https://retail.horizonbluedev.com/hc2/api/location/search?_format=json&zipcode=07105";
var array=[]; 
var rpn = require('request-promise-native')
module.exports= {
   
	getApi: async function(location)
	{
		array = []
		const api= await rpn.get(url+location)
		const res= JSON.parse(api);
       	res.providers.forEach(element => {
            array.push(element.firstname.toLowerCase());
        });
        return array;
	},

	getApi2:function(param)
	{
    return array.includes(param.toLowerCase());
	}

}
