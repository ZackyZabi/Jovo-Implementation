var api=require('./functions.js')
module.exports = {

    async bookAppointmentIntent() {
        if(this.$alexaSkill.hasSlotValue('shop') ){

                if(!api.getApi2(this.$inputs.shop.value)) 
                {
                    this.$alexaSkill.$dialog.elicitSlot('shop', 'The shopname that you have selected is not valid. Please select a valid shop name ', 'Your selection is invalid. Please select a valid shop name. ')
                }
                else if (this.$alexaSkill.hasSlotValue('time') && (this.$inputs.time.value == 'MO' | this.$inputs.time.value == 'EV' | this.$inputs.time.value == 'NI' | this.$inputs.time.value == 'AF')) 
                {
                    this.$alexaSkill.$dialog.elicitSlot('time', 'be specific on the ' + this.$inputs.time.value + '.', 'once again please')
                } else if (!this.$alexaSkill.$dialog.isCompleted()) 
                {
                    if (this.$alexaSkill.hasSlotValue('date') && this.$alexaSkill.hasSlotValue('time') && this.$alexaSkill.hasSlotValue('customerType') && this.$alexaSkill.hasSlotValue('reasonForVisit') && this.$alexaSkill.hasSlotValue('shop')) 
                    {
                        
                        let gName = this.$app.$data.key.fullname
                        let arry = gName.split(' ')
                        
                        let updatedIntent = {
                            name: 'bookAppointmentIntent',
                            confirmationStatus: 'NONE',
                            slots: {
                                customerType: {
                                    name: 'customerType',
                                    value: this.$inputs.customerType.value,
                                    confirmationStatus: 'NONE',
                                },
                                reasonForVisit: {
                                    name: 'reasonForVisit',
                                    value: this.$inputs.reasonForVisit.value,
                                    confirmationStatus: 'NONE',
                                },
                                firstName: {
                                    name: 'firstName',
                                    value: arry[0],
                                    confirmationStatus: 'NONE',
                                },
                                lastName: {
                                    name: 'lastName',
                                    value: arry[1],
                                    confirmationStatus: 'NONE',
                                },
                                date: {
                                    name: 'date',
                                    value: this.$inputs.date.value,
                                    confirmationStatus: 'NONE',
                                },
                                time: {
                                    name: 'time',
                                    value: this.$inputs.time.value,
                                    confirmationStatus: 'NONE',
                                },
                                bookAnAppointment: {
                                    name: 'bookAnAppointment',
                                    confirmationStatus: 'NONE',
                                },
                                 shop: {
                                    name: 'shop',
                                    value: this.$inputs.shop.value,
                                    confirmationStatus: 'NONE',
                                },

                            }
                        }
                        this.$alexaSkill.$dialog.delegate(updatedIntent)
                    } 
                    else {

                        this.$alexaSkill.$dialog.delegate()
                    }
                } 

              else{
               
                this.$speech.addText('Okay noted. Appointment on '+this.$inputs.date.value+' '+this.$inputs.time.value+' for the purpose of '+this.$inputs.reasonForVisit.value+' is marked, do you like to confirm');
                this.$reprompt.addText('Please answer with yes or no.');
        
                this.followUpState('perderState')
                    .ask(this.$speech, this.$reprompt);
                }
           }
           else
           {
            var info = {
                customer : this.$inputs.customerType.value,
                reason : this.$inputs.reasonForVisit.value,
                date : this.$inputs.date.value,
                time : this.$inputs.time.value
            }

           this.$app.$data.free = info;
           console.log(this.$app.$data.free)
           return this.toIntent("locationIntent") 
           }      

},
perderState: {

    YesIntent() {
        this.tell('Thank you for booking an appointment. your appointment is successfully booked and details are emailed to you.') 
    },

    NoIntent() {
        this.tell('fine, your appointment have been cancelled')
    },
},
}