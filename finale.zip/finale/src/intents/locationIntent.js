var api=require('./functions.js')

module.exports = {

    async locationOptionIntent() {
        result = []
        if(this.$alexaSkill.hasSlotValue('location'))
            {   
                result= await api.getApi(this.$inputs.location.value)
            }
            else
            {
                result= await api.getApi('10001')
            }          
            
            var temp = result.slice(this.$app.$data.static, this.$app.$data.iterator);

            console.log(this.$app.$data.static)
            console.log(this.$app.$data.iterator)
            console.log('-----------')

        if(this.$app.$data.static==0) 
           this.ask('These are the few show '+temp+' do you want some more')
        else
            this.ask(''+temp+'')
        
        this.$app.$data.static = this.$app.$data.iterator;
        this.$app.$data.iterator = this.$app.$data.iterator + 2;
        
}
}
